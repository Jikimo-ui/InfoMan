Updated the files for end_user
